#!/bin/sh
aplay /home/pi/printer_data/config/audio/print_start.wav
