#!/bin/sh
aplay /home/pi/printer_data/config/audio/printer_startup.wav

