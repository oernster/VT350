# VT350
Voron Trident Configuration
